create view stg_payments(customer_id, amount, payment_date) as
SELECT customer_id,
       amount,
       payment_date
FROM payment;

alter table stg_payments
    owner to postgres;

