create view new_model(cus_name, cus_surname) as
WITH customers_info AS (SELECT customer.first_name AS cus_name,
                               customer.last_name  AS cus_surname
                        FROM customer)
SELECT cus_name,
       cus_surname
FROM customers_info;

alter table new_model
    owner to postgres;

