create view int_count_customer(customer_id, date, number_of_orders) as
SELECT customer_id,
       date(payment_date) AS date,
       count(customer_id) AS number_of_orders
FROM stg_day_customer
GROUP BY customer_id, (date(payment_date))
ORDER BY customer_id, (date(payment_date));

alter table int_count_customer
    owner to postgres;

