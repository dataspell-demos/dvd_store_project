create view stg_customers_personal(customer_id, first_name, last_name, address, postal_code) as
SELECT customer.customer_id,
       customer.first_name,
       customer.last_name,
       address.address,
       address.postal_code
FROM customer
         LEFT JOIN address ON customer.address_id = address.address_id;

alter table stg_customers_personal
    owner to postgres;

