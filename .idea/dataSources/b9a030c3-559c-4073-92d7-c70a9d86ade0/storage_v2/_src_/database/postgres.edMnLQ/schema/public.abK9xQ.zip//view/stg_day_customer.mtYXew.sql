create view stg_day_customer(customer_id, payment_date, payment_id) as
SELECT customer_id,
       payment_date,
       payment_id
FROM payment;

alter table stg_day_customer
    owner to postgres;

