create view stg_payments(customer_id, amount) as
SELECT customer_id,
       amount
FROM payment;

alter table stg_payments
    owner to postgres;

