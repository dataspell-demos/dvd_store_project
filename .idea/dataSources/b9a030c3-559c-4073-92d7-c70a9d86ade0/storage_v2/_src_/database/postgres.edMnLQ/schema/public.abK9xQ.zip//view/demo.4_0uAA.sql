create view demo(cus_name, cus_surname) as
SELECT cus_name,
       cus_surname
FROM new_model;

alter table demo
    owner to postgres;

