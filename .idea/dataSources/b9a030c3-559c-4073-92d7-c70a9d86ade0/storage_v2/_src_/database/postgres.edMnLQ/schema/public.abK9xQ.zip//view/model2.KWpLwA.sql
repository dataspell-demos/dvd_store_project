create view model2(first_name) as
SELECT first_name
FROM model;

alter table model2
    owner to postgres;

