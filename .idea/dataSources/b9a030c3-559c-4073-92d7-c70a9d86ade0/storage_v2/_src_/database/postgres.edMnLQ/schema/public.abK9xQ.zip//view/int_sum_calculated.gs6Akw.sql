create view int_sum_calculated(customer_id, sum) as
SELECT customer_id,
       sum(amount) AS sum
FROM stg_payments
GROUP BY customer_id;

alter table int_sum_calculated
    owner to postgres;

